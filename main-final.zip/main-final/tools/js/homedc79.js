var lastPage = "page1";
var rand = 0;
var pw = $(window).width();
var ph = $(window).height();
var phcomm = $('.projComm ').height();
var isMb = false;
var ismenu = false;
if (pw < 960) {
    isMb = true;
}


$('.projTxt2').velocity({ opacity: "0", translateY: "500px" }, { delay: 0, duration: 0 });
$('.tabsComm').velocity({ opacity: "0", translateY: "-150%" }, { duration: 0 });
$('.page2_Circle').velocity({ scale: "0.4" }, { duration: 0 });
$('.page2 .page2_Circle').velocity({ translateY: "150px", opacity: "0" }, { duration: 0 });

$('#infoCont,#infoCont2').velocity({ scale: "0" }, { duration: 0, delay: 0 });

if (pw > 959) {
    $('#infoPanel').velocity({ translateX: "600px" }, { display: "none" }, { duration: 0, delay: 0 });
} else {
    $('#infoPanel').velocity({ translateX: "0px", opacity: "1" }, { display: "block" });

}


$('.btnsCont').velocity({ opacity: "0px" }, { duration: 0, delay: 0 });


function showtabs() {
    $('.back').addClass('logoActive');

    $('.tabsComm').each(function() {
        $(this).velocity({ opacity: "1", translateY: "0" }, { duration: 500, easing: [50, 8] });

    });
}



if (pw > 959 && pw < 1024) {
    ismenu = true;
}

function renderProgress(progress) {
    progress = Math.floor(progress);
    if (progress < 25) {
        var angle = -90 + (progress / 100) * 360;
        $(".animate-0-25-b").css("transform", "rotate(" + angle + "deg)");
    } else if (progress >= 25 && progress < 50) {
        var angle = -90 + ((progress - 25) / 100) * 360;
        $(".animate-0-25-b").css("transform", "rotate(0deg)");
        $(".animate-25-50-b").css("transform", "rotate(" + angle + "deg)");
    } else if (progress >= 50 && progress < 75) {
        var angle = -90 + ((progress - 50) / 100) * 360;
        $(".animate-25-50-b, .animate-0-25-b").css("transform", "rotate(0deg)");
        $(".animate-50-75-b").css("transform", "rotate(" + angle + "deg)");
    } else if (progress >= 75 && progress <= 100) {
        var angle = -90 + ((progress - 75) / 100) * 360;
        $(".animate-50-75-b, .animate-25-50-b, .animate-0-25-b").css("transform", "rotate(0deg)");
        $(".animate-75-100-b").css("transform", "rotate(" + angle + "deg)");
    }
    if (progress === 100) {}
}

function clearProgress() {
    $(".animate-75-100-b, .animate-50-75-b, .animate-25-50-b, .animate-0-25-b").css("transform", "rotate(90deg)");
}

var i = 0;
var maxRa = 100;
var inte;


if (!isMb) {
    var i = 0;
    var maxRa = 100;
    inte = setInterval(function() {
        i++;
        if (i === maxRa) {
            clear();
            $('.front,.back').addClass('active');
            $('#infoCont,#infoCont2').velocity({ scale: "1", opacity: "1" }, { duration: 800, delay: 400, easing: [500, 20] });
            showtabs();
        }

        renderProgress(i);
    }, 0);

}


function clear() {
    clearInterval(inte);
}

var ele;
var proj;
var cirang = 0;
var mang = 0;
$(document).ready(function() {
    $('input').bind('click', function() {
        $(this).attr('readonly', false);

    });
    //if(!isMb){
    // $('.page2').niceScroll({cursorcolor: "#666", cursorwidth: "4px", cursorborder: "0px solid #fff", cursoropacitymin: "0.2", cursoropacitymax: "0.7", railpadding: {top: 0, right: 0, left: 0, bottom: 0}});
    //}
    var cnt = $('.line').length;
    $('.line').each(function(i) {
        var val = i * (360 / cnt);
        $(this).css({ transform: "rotate(" + val + "deg)" });
    });


    var cnt2 = $('.line2').length;
    $('.line2').each(function(i) {
        var val = i * (180 / cnt2);
        /// $(this).css({ transform: "rotate(" + val + "deg)" });
    });



    $('.line2 .clickable').click(function() {
        clickableclick($(this));
    });



    $.fn.rotationInfo = function() {
        var el = $(this),
            tr = el.css("-webkit-transform") || el.css("-moz-transform") || el.css("-ms-transform") || el.css("-o-transform") || '',
            info = { rad: 0, deg: 0 };
        if (tr = tr.match('matrix\\((.*)\\)')) {
            tr = tr[1].split(',');
            if (typeof tr[0] != 'undefined' && typeof tr[1] != 'undefined') {
                info.rad = Math.atan2(tr[1], tr[0]);
                info.deg = parseFloat((info.rad * 180 / Math.PI).toFixed(1));
            }
        }
        return info;
    };

    $('.projTxt2').velocity({ translateY: "500px" }, { delay: 0, duration: 0 });
    $('.projComm .teamClose').velocity({ opacity: "0" }, { delay: 0, duration: 0 });

    $('.readMore.live').click(function() {
        readMoreClick($(this));
    });

    $(window).resize(function() {
        pw = $(window).width();
        ph = $(window).height();
    });

    $('.next').click(function() {
         
        rand++;
        invokeClick(rand);
    });

    $('.prev').click(function() {
       
        rand --;
        invokeClick(rand);
    });

});


function clickableclick(obj) {
    proj = obj.attr("data-for").split('proj');
    proj = proj[1];
    $('.line2 div').removeClass('activate');
    ele = obj;
    ele.addClass('activate');
    var ang = obj.parent().rotationInfo().deg;
    var txt = obj.html();

    ind = ele.index();


    if (ind == 0) {
        if (mang < 180) {
            mang = (180 - ang);
        } else {
            mang = (ang - 180) * -1;
        }
    } else if (ind == 2) {
        if (mang < 180) {
            mang = (180 - ang) - 180;
        } else {
            mang = ((0 - ang) - 0);
        }
    }
    if (!isMb) {
        $('#infoCont,#infoCont2').velocity({ rotateZ: mang }, {
            easing: "swing",
            complete: function() {
                moveCircle();
            }
        });

        $('#infoCont,#infoCont2').velocity({ scale: "0.9" }, { duration: 200, delay: 100, easing: "swing", queue: false });
        $('#infoCont,#infoCont2').velocity({ scale: "1" }, { duration: 300, delay: 200, easing: "swing", queue: false });
    } else {
        moveCircle();
    }
}

function readMoreClick(obj) {
    var id = obj.attr('id');
    var no = id.split("_");
    no = no[1];
    $('.homePageCont').velocity({ scale: "0.5" }, { delay: 0, duration: 200 }, { easing: "ease-in-out" });
    $('#infoPanel').velocity({ width: "100%" }, { delay: 10, duration: 300 }, { easing: "ease-in-out" });
    $('#projTxt_' + no).velocity({ opacity: "0" }, { delay: 100, duration: 100 }, { easing: "ease-in-out" });
    $('#projTxt_' + no).hide();
    $('#projTxt2_' + no).removeClass('dn');
    $('#projTxt2_' + no).velocity({ opacity: "1", translateY: "0" }, { delay: 400, duration: 500 }, { easing: "ease-in-out" });
    $('#teamClose_' + no).velocity({ opacity: "1" }, { delay: 0, duration: 100 });
    titleht = $('#proj' + no + ' .projTitle').outerHeight();

    if (isMb) {
        $('.floatingNext').hide();
        $('.projTitle').velocity({ height: "200px", lineHeight: "125px" }, { delay: 300, duration: 600 }, { easing: "ease-in-out" });
    } else {
        $('.projTitle').velocity({ height: "300px", lineHeight: "250px" }, { delay: 300, duration: 600 }, { easing: "ease-in-out" });
    }
    $('#btnsCont_' + no).removeClass('dn');
    setTimeout(function() {
        $('#btnsCont_' + no).velocity({ opacity: "1" }, { duration: 300, delay: 300 });
    }, 10);

    stop();
    move = false;

    // if(!isMb){
    setTimeout(function() {
        // $('.projDet,.projTxt2').niceScroll({cursorcolor: "#666", cursorwidth: "4px", cursorborder: "0px solid #fff", cursoropacitymin: "0", cursoropacitymax: "0.7", railpadding: {top: 0, right: 0, left: 0, bottom: 0}});

    }, 200);
}

var move = true;
var titleht;
var sinterval;
var scount = 1;
var moved = 0;

function moveCircle() {
    if (pw > 959 && pw < 1025) {
        $('.homePageCont').velocity({ translateX: "-200px" }, { duration: 300, delay: 0, easing: "ease-in-out" });
    } else {
        if (!isMb)
            $('.homePageCont').velocity({ translateX: "-300px" }, { duration: 300, delay: 0, easing: "ease-in-out" });
    }

    if (moved == 0) {
        $('#infoPanel').velocity({ translateX: "0px", opacity: "1" }, { display: "block" }, { duration: 300, delay: 0, easing: "ease-in-out" });
    }
    //    if(isMb){
    //        sinterval=setInterval(function(){
    //            invokeClick();
    //            console.log("here");
    //        },10000);
    //    }
    moved++;
    scount = (proj - 0);
    slipdeUp();
}


setTimeout(function() {
    //invokeClick();
    $('#infoCont,#infoCont2').velocity({ scale: "0.9" }, { duration: 200, delay: 100, easing: "swing", queue: false });
    $('#infoCont,#infoCont2').velocity({ scale: "1" }, { duration: 300, delay: 200, easing: "swing", queue: false });
    moveCircle();
}, 3000);



function slipdeUp() {

    //if(move){
    var val = scount * 100;
    $('.projComm').velocity('stop').velocity({ translateY: "-" + val + "%", opacity: "1" }, { duration: 1500, delay: 0, easing: [35, 8] });
    //}
}

function stop() {
    $('.projComm').velocity("stop");
    clearInterval(sinterval);
}




function invokeClick(rand) {
    $('.clickable').each(function(i) {
        var data = $(this).attr("data-for").split('proj');
        if(rand == 0){
            $('.projComm').velocity('stop').velocity({ translateY: "-0%", opacity: "1" }, { duration: 1500, delay: 0, easing: [35, 8] });
        }
        else if (data[1] == rand) {
            $(this).click();
            return;
        }
    });
    // rand++;

    if (rand >= 1 && rand < 15) {
        $('.next,.prev').removeClass('dn');
    } else if (rand == 0) {
        setTimeout(function(){
            $('.prev').addClass('dn');
        },10);
       
        $('.next').removeClass('dn');
    } else if (rand == 15) {
        $('.next').addClass('dn');
        $('.prev').removeClass('dn');
        rand = 1;
    }



}

var $example1 = $('.cirtxt').hide();
$example1.show().arctext({ radius: 145 });

$('#teamText').velocity({ opacity: 0, translateX: "150px" }, { delay: 0, duration: 0 });

function showMate(type) {
    type = parseInt(type);
    switch (type) {
        case 1:
            if (pw < 959) {
                $('#mate2,#mate3,#mate4,#mate5,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').addClass('dn');
                $('.pageComm').animate({ scrollTop: 237 }, 300, "swing");
            } else {
                $('#mate1').velocity({ scale: 1, translateX: "-20px" }, { delay: 0, duration: 200, easing: "ease-in-out" });
                $('#mate2,#mate3,#mate4,#mate5,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').velocity({ scale: 0 }, { delay: 0, duration: 200, easing: "ease-in-out" });
            }

            $('#mate1').velocity({ scale: 1 }, { delay: 0, duration: 200, easing: "ease-in-out" });
            $('#formate2,#formate3,#formate4,#formate5,#formate6,#formate7,#formate8,#formate9,#formate10,#formate11,#formate12').addClass('dn');
            $('#formate1').removeClass('dn');
            $('#teamText').removeClass('dn');
            $('#teamText').velocity({ opacity: 1, translateX: "0" }, { delay: 200, duration: 300, easing: "ease-in-out" });
            break;
        case 2:
            if (pw < 959) {
                $('#mate1,#mate3,#mate4,#mate5,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').addClass('dn');
                $('.pageComm').animate({ scrollTop: 230 }, 300, "swing");
            } else {
                var offCont = $('.dataCont').offset().left;
                var offThis = $('#mate2').offset().left;
                var finOff = offCont - offThis + 20;
                if (pw > 959 && pw < 1025) {
                    $('#mate2').velocity({ scale: 1, translateX: finOff }, { delay: 0, duration: 200, easing: "ease-in-out" });
                } else {
                    $('#mate2').velocity({ scale: 1, translateX: finOff }, { delay: 0, duration: 200, easing: "ease-in-out" });
                }
                $('#mate1,#mate3,#mate4,#mate5,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').velocity({ scale: 0 }, { delay: 0, duration: 200, easing: "ease-in-out" });
            }
            $('#formate1,#formate3,#formate4,#formate5,#formate6,#formate7,#formate8,#formate9,#formate10,#formate11,#formate12').addClass('dn');
            $('#formate2').removeClass('dn');
            $('#teamText').removeClass('dn');
            $('#teamText').velocity({ opacity: 1, translateX: "0" }, { delay: 200, duration: 300, easing: "ease-in-out" });
            break;
        case 3:
            if (pw < 959) {
                $('#mate1,#mate2,#mate4,#mate5,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').addClass('dn');
                $('.pageComm').animate({ scrollTop: 232 }, 300, "swing");
            } else {
                var offContY = $('.dataCont').offset().top;
                var offThisY = $('#mate3').offset().top;
                var finOffY = (offContY - offThisY + 20);
                var offCont = $('.dataCont').offset().left;
                var offThis = $('#mate3').offset().left;
                var finOff = offCont - offThis + 20;
                if (pw > 959 && pw < 1025) {
                    $('#mate3').velocity({ scale: 1, translateX: finOff, translateY: finOffY }, { delay: 0, duration: 200, easing: "ease-in-out" });
                } else {
                    $('#mate3').velocity({ scale: 1, translateX: finOff, translateY: finOffY }, { delay: 0, duration: 300, easing: "ease-in-out" });
                }
                $('#mate1,#mate2,#mate4,#mate5,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').velocity({ scale: 0 }, { delay: 0, duration: 300, easing: "ease-in-out" });

            }

            $('#formate1,#formate2,#formate4,#formate5,#formate6,#formate7,#formate8,#formate9,#formate10,#formate11,#formate12').addClass('dn');
            $('#formate3').removeClass('dn');
            $('#teamText').removeClass('dn');
            $('#teamText').velocity({ opacity: 1, translateX: "0" }, { delay: 300, duration: 300, easing: "ease-in-out" });
            break;
        case 4:

            if (pw < 959) {
                $('#mate1,#mate2,#mate3,#mate5,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').addClass('dn');
                $('.pageComm').animate({ scrollTop: 232 }, 300, "swing");
            } else {
                var offContY = $('.dataCont').offset().top;
                var offThisY = $('#mate4').offset().top;
                var finOffY = (offContY - offThisY + 20);
                var offCont = $('.dataCont').offset().left;
                var offThis = $('#mate4').offset().left;
                var finOff = (offCont - offThis + 20);

                if (pw < 1359) {
                    $('#mate4').velocity({ scale: 1, translateY: finOffY, translateX: finOff }, { delay: 0, duration: 200, easing: "ease-in-out" });
                } else {
                    $('#mate4').velocity({ scale: 1, translateX: finOff, translateY: "0px" }, { delay: 0, duration: 300, easing: "ease-in-out" });
                }
                $('#mate1,#mate2,#mate3,#mate5,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').velocity({ scale: 0 }, { delay: 0, duration: 300, easing: "ease-in-out" });

            }

            $('#formate1,#formate2,#formate3,#formate5,#formate6,#formate7,#formate8,#formate9,#formate10,#formate11,#formate12').addClass('dn');
            $('#formate4').removeClass('dn');
            $('#teamText').removeClass('dn');
            $('#teamText').velocity({ opacity: 1, translateX: "0" }, { delay: 300, duration: 300, easing: "ease-in-out" });
            break;

        case 5:
            if (pw < 959) {
                $('#mate1,#mate2,#mate3,#mate4,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').addClass('dn');
                $('.pageComm').animate({ scrollTop: 232 }, 300, "swing");
            } else {
                var offContY = $('.dataCont').offset().top;
                var offThisY = $('#mate5').offset().top;
                var finOffY = (offContY - offThisY + 20);
                var offCont = $('.dataCont').offset().left;
                var offThis = $('#mate5').offset().left;
                var finOff = (offCont - offThis + 20);

                if (pw < 1359) {
                    $('#mate5').velocity({ scale: 1, translateY: finOffY, translateX: finOff }, { delay: 0, duration: 200, easing: "ease-in-out" });
                } else {
                    $('#mate5').velocity({ scale: 1, translateX: finOff, translateY: "-400px" }, { delay: 0, duration: 300, easing: "ease-in-out" });
                }
                $('#mate1,#mate2,#mate3,#mate4,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').velocity({ scale: 0 }, { delay: 0, duration: 300, easing: "ease-in-out" });

            }

            $('#formate1,#formate2,#formate3,#formate4,#formate6,#formate7,#formate8,#formate9,#formate10,#formate11,#formate12').addClass('dn');
            $('#formate5').removeClass('dn');
            $('#teamText').removeClass('dn');
            $('#teamText').velocity({ opacity: 1, translateX: "0" }, { delay: 300, duration: 300, easing: "ease-in-out" });
            break;

        case 9:
            if (pw < 959) {
                $('#mate1,#mate2,#mate3,#mate4,#mate5,#mate7,#mate8,#mate6,#mate10,#mate11,#mate12').addClass('dn');
                $('.pageComm').animate({ scrollTop: 232 }, 300, "swing");
            } else {
                var offContY = $('.dataCont').offset().top;
                var offThisY = $('#mate9').offset().top;
                var finOffY = (offContY - offThisY + 20);
                var offCont = $('.dataCont').offset().left;
                var offThis = $('#mate9').offset().left;
                var finOff = (offCont - offThis + 20);

                if (pw < 1359) {
                    $('#mate9').velocity({ scale: 1, translateY: finOffY, translateX: finOff }, { delay: 0, duration: 200, easing: "ease-in-out" });
                } else {
                    $('#mate9').velocity({ scale: 1, translateX: finOff, translateY: "-400px" }, { delay: 0, duration: 300, easing: "ease-in-out" });
                }
                $('#mate1,#mate2,#mate3,#mate4,#mate5,#mate7,#mate8,#mate6,#mate10,#mate11,#mate12').velocity({ scale: 0 }, { delay: 0, duration: 300, easing: "ease-in-out" });

            }

            $('#formate1,#formate2,#formate3,#formate4,#formate5,#formate7,#formate8,#formate6,#formate10,#formate11,#formate12').addClass('dn');
            $('#formate9').removeClass('dn');
            $('#teamText').removeClass('dn');
            $('#teamText').velocity({ opacity: 1, translateX: "0" }, { delay: 300, duration: 300, easing: "ease-in-out" });
            break;

        case 10:
            if (pw < 959) {
                $('#mate1,#mate2,#mate3,#mate4,#mate5,#mate7,#mate8,#mate6,#mate9,#mate11,#mate12').addClass('dn');
                $('.pageComm').animate({ scrollTop: 232 }, 300, "swing");
            } else {
                var offContY = $('.dataCont').offset().top;
                var offThisY = $('#mate10').offset().top;
                var finOffY = (offContY - offThisY + 20);
                var offCont = $('.dataCont').offset().left;
                var offThis = $('#mate10').offset().left;
                var finOff = (offCont - offThis + 20);

                if (pw < 1359) {
                    $('#mate10').velocity({ scale: 1, translateY: finOffY, translateX: finOff }, { delay: 0, duration: 200, easing: "ease-in-out" });
                } else {
                    $('#mate10').velocity({ scale: 1, translateX: finOff, translateY: "-400px" }, { delay: 0, duration: 300, easing: "ease-in-out" });
                }
                $('#mate1,#mate2,#mate3,#mate4,#mate5,#mate7,#mate8,#mate6,#mate9,#mate11,#mate12').velocity({ scale: 0 }, { delay: 0, duration: 300, easing: "ease-in-out" });

            }

            $('#formate1,#formate2,#formate3,#formate4,#formate5,#formate7,#formate8,#formate6,#formate9,#formate11,#formate12').addClass('dn');
            $('#formate10').removeClass('dn');
            $('#teamText').removeClass('dn');
            $('#teamText').velocity({ opacity: 1, translateX: "0" }, { delay: 300, duration: 300, easing: "ease-in-out" });
            break;


        case 11:
            if (pw < 959) {
                $('#mate1,#mate2,#mate3,#mate4,#mate5,#mate7,#mate8,#mate6,#mate9,#mate10,#mate12').addClass('dn');
                $('.pageComm').animate({ scrollTop: 232 }, 300, "swing");
            } else {
                var offContY = $('.dataCont').offset().top;
                var offThisY = $('#mate11').offset().top;
                var finOffY = (offContY - offThisY + 20);
                var offCont = $('.dataCont').offset().left;
                var offThis = $('#mate11').offset().left;
                var finOff = (offCont - offThis + 20);

                if (pw < 1359) {
                    $('#mate11').velocity({ scale: 1, translateY: finOffY, translateX: finOff }, { delay: 0, duration: 200, easing: "ease-in-out" });
                } else {
                    $('#mate11').velocity({ scale: 1, translateX: finOff, translateY: "-800px" }, { delay: 0, duration: 300, easing: "ease-in-out" });
                }
                $('#mate1,#mate2,#mate3,#mate4,#mate5,#mate7,#mate8,#mate6,#mate9,#mate10,#mate12').velocity({ scale: 0 }, { delay: 0, duration: 300, easing: "ease-in-out" });

            }

            $('#formate1,#formate2,#formate3,#formate4,#formate5,#formate7,#formate8,#formate6,#formate9,#formate10,#formate12').addClass('dn');
            $('#formate11').removeClass('dn');
            $('#teamText').removeClass('dn');
            $('#teamText').velocity({ opacity: 1, translateX: "0" }, { delay: 300, duration: 300, easing: "ease-in-out" });
            break;

        case 12:
            if (pw < 959) {
                $('#mate1,#mate2,#mate3,#mate4,#mate5,#mate7,#mate8,#mate6,#mate9,#mate10,#mate11').addClass('dn');
                $('.pageComm').animate({ scrollTop: 232 }, 300, "swing");
            } else {
                var offContY = $('.dataCont').offset().top;
                var offThisY = $('#mate12').offset().top;
                var finOffY = (offContY - offThisY + 20);
                var offCont = $('.dataCont').offset().left;
                var offThis = $('#mate12').offset().left;
                var finOff = (offCont - offThis + 20);

                if (pw < 1359) {
                    $('#mate12').velocity({ scale: 1, translateY: finOffY, translateX: finOff }, { delay: 0, duration: 200, easing: "ease-in-out" });
                } else {
                    $('#mate12').velocity({ scale: 1, translateX: finOff, translateY: "-800px" }, { delay: 0, duration: 300, easing: "ease-in-out" });
                }
                $('#mate1,#mate2,#mate3,#mate4,#mate5,#mate7,#mate8,#mate6,#mate9,#mate10,#mate11').velocity({ scale: 0 }, { delay: 0, duration: 300, easing: "ease-in-out" });

            }

            $('#formate1,#formate2,#formate3,#formate4,#formate5,#formate7,#formate8,#formate6,#formate9,#formate10,#formate11').addClass('dn');
            $('#formate12').removeClass('dn');
            $('#teamText').removeClass('dn');
            $('#teamText').velocity({ opacity: 1, translateX: "0" }, { delay: 300, duration: 300, easing: "ease-in-out" });
            break;
    }
    $('body,html').scrollTop(0);
}

function hidemate(type) {
    type = parseInt(type);
    $('#teamText').velocity({ opacity: 0, translateX: "150px" }, { delay: 0, duration: 200, easing: "ease-in-out" });
    switch (type) {
        case 1:
            $('#mate2,#mate3,#mate4,#mate5,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').velocity({ scale: 1 }, { delay: 400, duration: 300, easing: "ease-in-out" });
            $('#mate1').velocity({ translateX: "0" }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate2,#mate3,#mate4,#mate5,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').removeClass('dn');
            break;
        case 2:
            $('#mate1,#mate3,#mate4,#mate5,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').velocity({ scale: 1 }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate2').velocity({ translateX: "0" }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate1,#mate3,#mate4,#mate5,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').removeClass('dn');
            break;
        case 3:
            $('#mate1,#mate2,#mate4,#mate5,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').velocity({ scale: 1 }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate3').velocity({ translateX: "0", translateY: "0" }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate1,#mate2,#mate4,#mate5,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').removeClass('dn');
            break;
        case 4:
            $('#mate1,#mate2,#mate3,#mate5,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').velocity({ scale: 1 }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate4').velocity({ translateX: "0", translateY: "0" }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate1,#mate2,#mate3,#mate5,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').removeClass('dn');
            break;
        case 5:
            $('#mate1,#mate2,#mate3,#mate4,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').velocity({ scale: 1 }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate5').velocity({ translateX: "0", translateY: "0" }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate1,#mate2,#mate3,#mate4,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate12').removeClass('dn');
            break;
        case 9:
            $('#mate1,#mate2,#mate3,#mate4,#mate6,#mate7,#mate8,#mate5,#mate10,#mate11,#mate12').velocity({ scale: 1 }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate9').velocity({ translateX: "0", translateY: "0" }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate1,#mate2,#mate3,#mate4,#mate6,#mate7,#mate8,#mate5,#mate10,#mate11,#mate12').removeClass('dn');
            break;
        case 10:
            $('#mate1,#mate2,#mate3,#mate4,#mate6,#mate7,#mate8,#mate9,#mate5,#mate11,#mate12').velocity({ scale: 1 }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate10').velocity({ translateX: "0", translateY: "0" }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate1,#mate2,#mate3,#mate4,#mate6,#mate7,#mate8,#mate9,#mate5,#mate11,#mate12').removeClass('dn');
            break;
        case 11:
            $('#mate1,#mate2,#mate3,#mate4,#mate6,#mate7,#mate8,#mate9,#mate10,#mate5,#mate12').velocity({ scale: 1 }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate11').velocity({ translateX: "0", translateY: "0" }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate1,#mate2,#mate3,#mate4,#mate6,#mate7,#mate8,#mate9,#mate10,#mate5,#mate12').removeClass('dn');
            break;
        case 12:
            $('#mate1,#mate2,#mate3,#mate4,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate5').velocity({ scale: 1 }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate12').velocity({ translateX: "0", translateY: "0" }, { delay: 0, duration: 300, easing: "ease-in-out" });
            $('#mate1,#mate2,#mate3,#mate4,#mate6,#mate7,#mate8,#mate9,#mate10,#mate11,#mate5').removeClass('dn');
            break;
    }


    if (pw < 959) {
        setTimeout(function() {
            $('#teamText,#formate1,#formate2,#formate3,#formate4,#formate5,#formate6,#formate7,#formate8,#formate9,#formate10,#formate11,#formate12').addClass('dn');
        }, 100);
    } else {
        setTimeout(function() {
            $('#teamText,#formate1,#formate2,#formate3,#formate4,#formate5,#formate6,#formate7,#formate8,#formate9,#formate10,#formate11,#formate12').addClass('dn');
        }, 700);
    }
}

function closePrj(no) {

    // if(!isMb){
    $('#projTxt2_' + no).velocity({ translateY: "500px" }, { delay: 0, duration: 300 }, { easing: "ease-in-out" });
    //$('.projDet').getNiceScroll().hide();
    // }




    if (pw < 959) {
        $('.floatingNext').show();
        $('#infoPanel').velocity({ width: "100%" }, { delay: 100, duration: 300 }, { easing: "ease-in-out" });
        $('#btnsCont_' + no).velocity({ opacity: "0" }, { duration: 300, delay: 0 });
        setTimeout(function() {
            $('#btnsCont_' + no).addClass('dn');
        }, 300);
    } else if (pw > 959 && pw < 1025) {
        $('#infoPanel').velocity({ width: "400px" }, { delay: 100, duration: 300 }, { easing: "ease-in-out" });
    } else {
        $('#infoPanel').velocity({ width: "600px" }, { delay: 100, duration: 300 }, { easing: "ease-in-out" });
        $('#btnsCont_' + no).velocity({ opacity: "0" }, { duration: 300, delay: 0 });
        setTimeout(function() {
            $('#btnsCont_' + no).addClass('dn');
        }, 300);

    }

    if (pw < 959) {
        $('.projTitle').velocity({ height: titleht + "px", lineHeight: "50px" }, { delay: 300, duration: 700 }, { easing: "ease-in-out" });
    } else {
        $('.projTitle').velocity({ height: "150px", lineHeight: "150px" }, { delay: 300, duration: 700 }, { easing: "ease-in-out" });
    }


    $('.homePageCont').velocity({ scale: "1" }, { delay: 300, duration: 200 }, { easing: "ease-in-out" });
    $('#teamClose_' + no).velocity({ opacity: "0" }, { delay: 0, duration: 100 });

    setTimeout(function() {
        $('#projTxt_' + no).show();
        $('#projTxt_' + no).velocity({ opacity: "1" }, { delay: 100, duration: 300 }, { easing: "ease-in-out" });
        $('#projTxt2_' + no).addClass('dn');
    }, 500);


    if (isMb) {
        $('.floatingNext').removeClass('dn');
    }
}

function ShowProj(projid) {
    $('.clickable').each(function() {
        var proj = $(this).attr("data-for").split('proj');
        proj = proj[1];
        if (projid === proj) {
            $(this).click();
            setTimeout(function() {
                movePage('page1');
            }, 200);
        }
    });
}

$(document).ready(function() {
    var id = $('.pageComm').attr('id');
    if (id !== 'page1')
        $('.page2_Circle').velocity({ opacity: "1", scale: "1", translateY: "0" }, { duration: 300, delay: 150, easing: "ease-in-out" });
});